import type { Express } from "express";
import { createServer, type Server } from "http";
import { ObjectId } from "mongodb";
import {
  connectToDatabase,
  getUsersCollection,
  getCampaignsCollection,
  getCustomerTasksCollection,
} from "./database";

export async function registerRoutes(app: Express): Promise<Server> {
  await connectToDatabase();

  // ✅ GET customer tasks (STRICT: max 30 tasks, never negative)
  app.get("/api/frontend/customer-tasks/:customerId", async (req, res) => {
    try {
      const { customerId } = req.params;
      console.log("📋 [TASKS-GET] Fetching tasks for customer:", customerId);

      const customerTasksCollection = getCustomerTasksCollection();
      let tasks = await customerTasksCollection
        .find({ customerId })
        .sort({ taskNumber: 1 })
        .toArray();

      if (tasks.length === 0) {
        console.log("ℹ️ [TASKS-GET] No tasks found → initializing 30.");

        const campaignsCollection = getCampaignsCollection();
        const campaigns = await campaignsCollection.find().limit(30).toArray();
        const usersCollection = getUsersCollection();
        const customer = await usersCollection.findOne({ _id: new ObjectId(customerId) });
        if (!customer) return res.json({ success: true, data: [], total: 0 });

        const now = new Date();
        const newTasks = campaigns.map((c, i) => ({
          customerId,
          customerCode: customer.membershipId || "",
          taskNumber: i + 1,
          campaignId: c._id!.toString(),
          taskCommission: Number(c.commissionAmount || 0),
          taskPrice: Number(c.baseAmount || 0),
          estimatedNegativeAmount: 0,
          priceFrom: Number(c.priceFrom || 0),
          priceTo: Number(c.priceTo || 0),
          hasGoldenEgg: Boolean(c.type === "Paid" || Number(c.baseAmount || 0) > 10000),
          expiredDate: c.endDate || new Date(now.getTime() + 30 * 86400000),
          status: "pending",
          createdAt: now,
          updatedAt: now,
        }));

        if (newTasks.length) {
          await customerTasksCollection.insertMany(newTasks);
          tasks = await customerTasksCollection.find({ customerId }).sort({ taskNumber: 1 }).toArray();
          console.log(`✅ Initialized ${tasks.length} tasks.`);
        }
      }

      const limited = tasks.slice(0, 30);
      if (tasks.length > 30) console.log(`🔒 Only returning first 30 of ${tasks.length}.`);

      res.json({ success: true, data: limited, total: limited.length });
    } catch (err) {
      console.error("❌ [TASKS-GET]", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // ✅ Save/Update a task (never negative)
  app.post("/api/frontend/customer-tasks", async (req, res) => {
    try {
      const { customerId, taskNumber, taskCommission, taskPrice, expiredDate, priceFrom, priceTo, status } = req.body;
      console.log("💾 [TASKS-SAVE]", { customerId, taskNumber });

      const tn = Number(taskNumber);
      if (!customerId || !tn || tn < 1 || tn > 30)
        return res.status(400).json({ success: false, error: "Invalid task number (must be 1–30)." });

      const customerTasksCollection = getCustomerTasksCollection();

      const safeNum = (v: any) => (isNaN(Number(v)) ? 0 : Number(v));
      const updateData: any = {
        taskCommission: safeNum(taskCommission),
        taskPrice: safeNum(taskPrice),
        estimatedNegativeAmount: 0,
        priceFrom: safeNum(priceFrom),
        priceTo: safeNum(priceTo),
        updatedAt: new Date(),
      };

      if (expiredDate) updateData.expiredDate = new Date(expiredDate);
      if (status) updateData.status = status;

      const result = await customerTasksCollection.findOneAndUpdate(
        { customerId, taskNumber: tn },
        { $set: updateData },
        { returnDocument: "after" }
      );

      if (!result) return res.status(404).json({ success: false, error: "Task not found." });

      console.log("✅ [TASKS-SAVE] Updated task #", tn);
      res.json({ success: true, data: result, message: "Task updated successfully." });
    } catch (err) {
      console.error("❌ [TASKS-SAVE]", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // ✅ Allow tasks (init 30 max)
  app.post("/api/frontend/customer-tasks/allow/:customerId", async (req, res) => {
    try {
      const { customerId } = req.params;
      console.log("🟢 [TASKS-ALLOW]", customerId);

      const customerTasksCollection = getCustomerTasksCollection();
      const existing = await customerTasksCollection.find({ customerId }).toArray();
      if (existing.length >= 30) {
        console.log(`🔒 Already ${existing.length} tasks.`);
      } else if (existing.length === 0) {
        const campaignsCollection = getCampaignsCollection();
        const campaigns = await campaignsCollection.find().limit(30).toArray();
        const usersCollection = getUsersCollection();
        const customer = await usersCollection.findOne({ _id: new ObjectId(customerId) });
        if (!customer) return res.status(404).json({ success: false, error: "Customer not found" });

        const now = new Date();
        const newTasks = campaigns.map((c, i) => ({
          customerId,
          customerCode: customer.membershipId || "",
          taskNumber: i + 1,
          campaignId: c._id!.toString(),
          taskCommission: Number(c.commissionAmount || 0),
          taskPrice: Number(c.baseAmount || 0),
          estimatedNegativeAmount: 0,
          priceFrom: Number(c.priceFrom || 0),
          priceTo: Number(c.priceTo || 0),
          hasGoldenEgg: Boolean(c.type === "Paid" || Number(c.baseAmount || 0) > 10000),
          expiredDate: c.endDate || new Date(now.getTime() + 30 * 86400000),
          status: "pending",
          createdAt: now,
          updatedAt: now,
        }));
        await customerTasksCollection.insertMany(newTasks);
        console.log(`✅ Created ${newTasks.length} tasks.`);
      }

      const usersCollection = getUsersCollection();
      await usersCollection.updateOne(
        { _id: new ObjectId(customerId) },
        { $set: { allowTask: true, updatedAt: new Date() } }
      );

      const count = await customerTasksCollection.countDocuments({ customerId });
      res.json({ success: true, message: "Tasks allowed (max 30).", count: Math.min(count, 30) });
    } catch (err) {
      console.error("❌ [TASKS-ALLOW]", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // ✅ Admin manual reset
  app.post("/api/admin/reset-customer-tasks/:customerId", async (req, res) => {
    try {
      const { customerId } = req.params;
      console.log("🧹 [ADMIN-RESET]", customerId);

      const customerTasksCollection = getCustomerTasksCollection();
      const usersCollection = getUsersCollection();
      const campaignsCollection = getCampaignsCollection();

      const customer = await usersCollection.findOne({ _id: new ObjectId(customerId) });
      if (!customer) return res.status(404).json({ success: false, error: "Customer not found" });

      await customerTasksCollection.deleteMany({ customerId });
      console.log("🗑️ Old tasks removed.");

      const campaigns = await campaignsCollection.find().limit(30).toArray();
      const now = new Date();
      const newTasks = campaigns.map((c, i) => ({
        customerId,
        customerCode: customer.membershipId || "",
        taskNumber: i + 1,
        campaignId: c._id!.toString(),
        taskCommission: Number(c.commissionAmount || 0),
        taskPrice: Number(c.baseAmount || 0),
        estimatedNegativeAmount: 0,
        priceFrom: Number(c.priceFrom || 0),
        priceTo: Number(c.priceTo || 0),
        hasGoldenEgg: Boolean(c.type === "Paid" || Number(c.baseAmount || 0) > 10000),
        expiredDate: c.endDate || new Date(now.getTime() + 30 * 86400000),
        status: "pending",
        createdAt: now,
        updatedAt: now,
      }));
      await customerTasksCollection.insertMany(newTasks);
      console.log(`✅ Reset ${newTasks.length} tasks.`);

      res.json({ success: true, message: "Tasks reset successfully.", count: newTasks.length });
    } catch (err) {
      console.error("❌ [ADMIN-RESET]", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  return createServer(app);
}